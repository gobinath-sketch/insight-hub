<!-- GENERATED FILE: do not edit directly -->
<!--lint disable remark-lint:awesome-badge-->

<h3 align="center">Pick Your Style:</h3>
<p align="center">
<a href="../"><img src="../assets/badge-style-awesome.svg" alt="Awesome" height="28"></a>
<a href="README_EXTRA.md"><img src="../assets/badge-style-extra.svg" alt="Extra" height="28"></a>
<a href="README_CLASSIC.md"><img src="../assets/badge-style-classic.svg" alt="Classic" height="28"></a>
<a href="README_FLAT_ALL_AZ.md"><img src="../assets/badge-style-flat.svg" alt="Flat" height="28" style="border: 2px solid #71717a; border-radius: 4px;"></a>
</p>

# Awesome Claude Code (Flat)

[![Awesome](https://awesome.re/badge-flat2.svg)](https://awesome.re)

A flat list view of all resources. Category: **Tooling** | Sorted: by latest release (30 days)

---

## Sort By:

<p align="center">
  <a href="README_FLAT_TOOLING_AZ.md"><img src="../assets/badge-sort-az.svg" alt="A - Z" height="48"></a>
  <a href="README_FLAT_TOOLING_UPDATED.md"><img src="../assets/badge-sort-updated.svg" alt="UPDATED" height="48"></a>
  <a href="README_FLAT_TOOLING_CREATED.md"><img src="../assets/badge-sort-created.svg" alt="CREATED" height="48"></a>
  <a href="README_FLAT_TOOLING_RELEASES.md"><img src="../assets/badge-sort-releases.svg" alt="RELEASES" height="48" style="border: 3px solid #f59e0b; border-radius: 6px;"></a>
</p>
<p align="center"><strong>Category:</strong></p>
<p align="center">
  <a href="README_FLAT_ALL_RELEASES.md"><img src="../assets/badge-cat-all.svg" alt="All" height="28"></a>
  <a href="README_FLAT_TOOLING_RELEASES.md"><img src="../assets/badge-cat-tooling.svg" alt="Tooling" height="28" style="border: 2px solid #3b82f6; border-radius: 4px;"></a>
  <a href="README_FLAT_COMMANDS_RELEASES.md"><img src="../assets/badge-cat-commands.svg" alt="Commands" height="28"></a>
  <a href="README_FLAT_CLAUDE-MD_RELEASES.md"><img src="../assets/badge-cat-claude-md.svg" alt="CLAUDE.md" height="28"></a>
  <a href="README_FLAT_WORKFLOWS_RELEASES.md"><img src="../assets/badge-cat-workflows.svg" alt="Workflows" height="28"></a>
  <a href="README_FLAT_HOOKS_RELEASES.md"><img src="../assets/badge-cat-hooks.svg" alt="Hooks" height="28"></a>
  <a href="README_FLAT_SKILLS_RELEASES.md"><img src="../assets/badge-cat-skills.svg" alt="Skills" height="28"></a>
  <a href="README_FLAT_STYLES_RELEASES.md"><img src="../assets/badge-cat-styles.svg" alt="Styles" height="28"></a>
  <a href="README_FLAT_STATUSLINE_RELEASES.md"><img src="../assets/badge-cat-statusline.svg" alt="Status" height="28"></a>
  <a href="README_FLAT_DOCS_RELEASES.md"><img src="../assets/badge-cat-docs.svg" alt="Docs" height="28"></a>
  <a href="README_FLAT_CLIENTS_RELEASES.md"><img src="../assets/badge-cat-clients.svg" alt="Clients" height="28"></a>
</p>
<p align="center"><em>Currently viewing: **Tooling** sorted by latest release (30 days) (past 30 days)</em></p>

---

## Resources

> **Note:** Latest release data is pulled from GitHub Releases only. Projects without GitHub Releases will not show release info here. Please verify with the project directly.

<table>
<thead>
<tr>
<th>Resource</th>
<th>Version</th>
<th>Source</th>
<th>Release Date</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://github.com/matt1398/claude-devtools"><b>claude-devtools</b></a><br>by <a href="https://github.com/matt1398">matt1398</a></td>
<td>v0.4.9</td>
<td>GitHub</td>
<td>2026-03-23</td>
<td>A well-designed desktop app that provides detailed observability into your Claude Code sessions by analyzing the session logs. Provides turn-based context data across numerous categories, compaction visualization, subagent execution trees, and custom notification triggers. Easy to install, and nice visual design.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/matt1398/claude-devtools?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/matt1398/claude-devtools?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/matt1398/claude-devtools?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/matt1398/claude-devtools?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/matt1398/claude-devtools?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/matt1398/claude-devtools?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/matt1398/claude-devtools?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/matt1398/claude-devtools?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/matt1398/claude-devtools?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/agent-sh/agnix"><b>agnix</b></a><br>by <a href="https://github.com/agent-sh">agent-sh</a></td>
<td>v0.16.5</td>
<td>GitHub</td>
<td>2026-03-23</td>
<td>A comprehensive linter for Claude Code agent files. Validate CLAUDE.md, AGENTS.md, SKILL.md, hooks, MCP, and more. Plugin for all major IDEs included, with auto-fixes.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/agent-sh/agnix?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/agent-sh/agnix?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/agent-sh/agnix?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/agent-sh/agnix?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/agent-sh/agnix?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/agent-sh/agnix?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/agent-sh/agnix?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/agent-sh/agnix?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/agent-sh/agnix?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/ruvnet/ruflo"><b>Ruflo</b></a><br>by <a href="https://github.com/ruvnet">rUv</a></td>
<td>v3.5.31</td>
<td>GitHub</td>
<td>2026-03-18</td>
<td>An orchestration platform for deploying and coordinating multi-agent swarms. If I tried to go into detail it would probably crash my browser. An impressive feat of engineering that tries to cover everything and actually does a good job. Self-learning, autonomous multi-agent swarms, vector-based multi-layered memory, systematic planning, security guardrails, and so on. It's a growing project, and YMMV, but even just studying the patterns is immensely valuable, and it's clearly well-engineered.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/ruvnet/ruflo?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/ruvnet/ruflo?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/ruvnet/ruflo?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/ruvnet/ruflo?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/ruvnet/ruflo?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/ruvnet/ruflo?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/ruvnet/ruflo?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/ruvnet/ruflo?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/ruvnet/ruflo?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/dtormoen/tsk"><b>TSK - AI Agent Task Manager and Sandbox</b></a><br>by <a href="https://github.com/dtormoen">dtormoen</a></td>
<td>v0.10.4</td>
<td>GitHub</td>
<td>2026-03-14</td>
<td>A Rust CLI tool that lets you delegate development tasks to AI agents running in sandboxed Docker environments. Multiple agents work in parallel, returning git branches for human review.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/dtormoen/tsk?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/dtormoen/tsk?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/dtormoen/tsk?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/dtormoen/tsk?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/dtormoen/tsk?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/dtormoen/tsk?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/dtormoen/tsk?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/dtormoen/tsk?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/dtormoen/tsk?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/tombii/better-ccflare/"><b>ccflare -> **better-ccflare**</b></a><br>by <a href="https://github.com/tombii">tombii</a></td>
<td>v3.3.10</td>
<td>GitHub</td>
<td>2026-03-14</td>
<td>A well-maintained and feature-enhanced fork of the glorious `ccflare` usage dashboard by @snipeship (which at the time of writing has not had an update in a few months). `better-ccflare` builds on this foundation with some performance enhancements, extended provider support, bug fixes, Docker deployment, and more.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/tombii/better-ccflare?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/tombii/better-ccflare?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/tombii/better-ccflare?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/tombii/better-ccflare?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/tombii/better-ccflare?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/tombii/better-ccflare?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/tombii/better-ccflare?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/tombii/better-ccflare?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/tombii/better-ccflare?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/mbailey/voicemode"><b>VoiceMode MCP</b></a><br>by <a href="https://github.com/mbailey">Mike Bailey</a></td>
<td>v8.5.1</td>
<td>GitHub</td>
<td>2026-03-13</td>
<td>VoiceMode MCP brings natural conversations to Claude Code. It supports any OpenAI API compatible voice services and installs free and open source voice services (Whisper.cpp and Kokoro-FastAPI).</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/mbailey/voicemode?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/mbailey/voicemode?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/mbailey/voicemode?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/mbailey/voicemode?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/mbailey/voicemode?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/mbailey/voicemode?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/mbailey/voicemode?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/mbailey/voicemode?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/mbailey/voicemode?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/dyoshikawa/rulesync"><b>Rulesync</b></a><br>by <a href="https://github.com/dyoshikawa">dyoshikawa</a></td>
<td>v7.18.2</td>
<td>GitHub</td>
<td>2026-03-13</td>
<td>A Node.js CLI tool that automatically generates configs (rules, ignore files, MCP servers, commands, and subagents) for various AI coding agents. Rulesync can convert configs between Claude Code and other AI agents in both directions.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/dyoshikawa/rulesync?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/dyoshikawa/rulesync?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/dyoshikawa/rulesync?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/dyoshikawa/rulesync?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/dyoshikawa/rulesync?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/dyoshikawa/rulesync?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/dyoshikawa/rulesync?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/dyoshikawa/rulesync?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/dyoshikawa/rulesync?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/Haleclipse/Claudix"><b>Claudix - Claude Code for VSCode</b></a><br>by <a href="https://github.com/Haleclipse">Haleclipse</a></td>
<td>0.3.9-dev</td>
<td>GitHub</td>
<td>2026-03-13</td>
<td>A VSCode extension that brings Claude Code directly into your editor with interactive chat interface, session management, intelligent file operations, terminal execution, and real-time streaming responses. Built with Vue 3, TypeScript.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/Haleclipse/Claudix?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/Haleclipse/Claudix?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/Haleclipse/Claudix?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/Haleclipse/Claudix?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/Haleclipse/Claudix?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/Haleclipse/Claudix?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/Haleclipse/Claudix?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/Haleclipse/Claudix?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/Haleclipse/Claudix?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/smtg-ai/claude-squad"><b>Claude Squad</b></a><br>by <a href="https://github.com/smtg-ai">smtg-ai</a></td>
<td>v1.0.17</td>
<td>GitHub</td>
<td>2026-03-12</td>
<td>Claude Squad is a terminal app that manages multiple Claude Code, Codex (and other local agents including Aider) in separate workspaces, allowing you to work on multiple tasks simultaneously.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/smtg-ai/claude-squad?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/smtg-ai/claude-squad?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/smtg-ai/claude-squad?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/smtg-ai/claude-squad?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/smtg-ai/claude-squad?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/smtg-ai/claude-squad?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/smtg-ai/claude-squad?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/smtg-ai/claude-squad?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/smtg-ai/claude-squad?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/serpro69/claude-toolbox"><b>claude-toolbox</b></a><br>by <a href="https://github.com/serpro69">serpro69</a></td>
<td>v0.3.0</td>
<td>GitHub</td>
<td>2026-03-11</td>
<td>This is a starter template repository designed to provide a complete development environment for Claude-Code with pre-configured MCP servers and tools for AI-powered development workflows. The repository is intentionally minimal, containing only configuration templates for three primary systems: Claude Code, Serena, and Task Master.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/serpro69/claude-toolbox?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/serpro69/claude-toolbox?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/serpro69/claude-toolbox?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/serpro69/claude-toolbox?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/serpro69/claude-toolbox?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/serpro69/claude-toolbox?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/serpro69/claude-toolbox?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/serpro69/claude-toolbox?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/serpro69/claude-toolbox?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/ryoppippi/ccusage"><b>CC Usage</b></a><br>by <a href="https://github.com/ryoppippi">ryoppippi</a></td>
<td>v18.0.10</td>
<td>GitHub</td>
<td>2026-03-10</td>
<td>Handy CLI tool for managing and analyzing Claude Code usage, based on analyzing local Claude Code logs. Presents a nice dashboard regarding cost information, token consumption, etc.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/ryoppippi/ccusage?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/ryoppippi/ccusage?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/ryoppippi/ccusage?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/ryoppippi/ccusage?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/ryoppippi/ccusage?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/ryoppippi/ccusage?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/ryoppippi/ccusage?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/ryoppippi/ccusage?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/ryoppippi/ccusage?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/pchalasani/claude-code-tools"><b>claude-code-tools</b></a><br>by <a href="https://github.com/pchalasani">Prasad Chalasani</a></td>
<td>v1.10.8</td>
<td>GitHub</td>
<td>2026-03-09</td>
<td>Well-crafted toolset for session continuity, featuring skills/commands to avoid compaction and recover context across sessions with cross-agent handoff between Claude Code and Codex CLI. Includes a fast Rust/Tantivy-powered full-text session search (TUI for humans, skill/CLI for agents), tmux-cli skill + command for interacting with scripts and CLI agents, and safety hooks to block dangerous commands.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/pchalasani/claude-code-tools?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/pchalasani/claude-code-tools?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/pchalasani/claude-code-tools?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/pchalasani/claude-code-tools?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/pchalasani/claude-code-tools?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/pchalasani/claude-code-tools?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/pchalasani/claude-code-tools?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/pchalasani/claude-code-tools?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/pchalasani/claude-code-tools?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/ruvnet/claude-code-flow"><b>Claude Code Flow</b></a><br>by <a href="https://github.com/ruvnet">ruvnet</a></td>
<td>v3.5.15</td>
<td>GitHub</td>
<td>2026-03-09</td>
<td>This mode serves as a code-first orchestration layer, enabling Claude to write, edit, test, and optimize code autonomously across recursive agent cycles.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/ruvnet/claude-code-flow?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/ruvnet/claude-code-flow?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/ruvnet/claude-code-flow?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/ruvnet/claude-code-flow?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/ruvnet/claude-code-flow?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/ruvnet/claude-code-flow?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/ruvnet/claude-code-flow?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/ruvnet/claude-code-flow?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/ruvnet/claude-code-flow?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/sudocode-ai/sudocode"><b>sudocode</b></a><br>by <a href="https://github.com/ssh-randy">ssh-randy</a></td>
<td>v0.1.26</td>
<td>GitHub</td>
<td>2026-03-07</td>
<td>Lightweight agent orchestration dev tool that lives in your repo. Integrates with various specification frameworks. It's giving Jira.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/sudocode-ai/sudocode?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/sudocode-ai/sudocode?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/sudocode-ai/sudocode?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/sudocode-ai/sudocode?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/sudocode-ai/sudocode?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/sudocode-ai/sudocode?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/sudocode-ai/sudocode?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/sudocode-ai/sudocode?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/sudocode-ai/sudocode?style=flat-square" alt="license"></td>
</tr>
<tr>
<td><a href="https://github.com/Piebald-AI/tweakcc"><b>tweakcc</b></a><br>by <a href="https://github.com/Piebald-AI">Piebald-AI</a></td>
<td>v4.0.11</td>
<td>GitHub</td>
<td>2026-03-05</td>
<td>Command-line tool to customize your Claude Code styling.</td>
</tr>
<tr>
<td colspan="5"><img src="https://img.shields.io/github/stars/Piebald-AI/tweakcc?style=flat-square" alt="stars"> <img src="https://img.shields.io/github/forks/Piebald-AI/tweakcc?style=flat-square" alt="forks"> <img src="https://img.shields.io/github/issues/Piebald-AI/tweakcc?style=flat-square" alt="issues"> <img src="https://img.shields.io/github/issues-pr/Piebald-AI/tweakcc?style=flat-square" alt="prs"> <img src="https://img.shields.io/github/created-at/Piebald-AI/tweakcc?style=flat-square" alt="created"> <img src="https://img.shields.io/github/last-commit/Piebald-AI/tweakcc?style=flat-square" alt="last-commit"> <img src="https://img.shields.io/github/release-date/Piebald-AI/tweakcc?style=flat-square" alt="release-date"> <img src="https://img.shields.io/github/v/release/Piebald-AI/tweakcc?style=flat-square" alt="version"> <img src="https://img.shields.io/github/license/Piebald-AI/tweakcc?style=flat-square" alt="license"></td>
</tr>
</tbody>
</table>

---

**Total Resources:** 15

**Last Generated:** 2026-04-04
